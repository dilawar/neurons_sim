from neuron.tests import test_all

suite = test_all.suite


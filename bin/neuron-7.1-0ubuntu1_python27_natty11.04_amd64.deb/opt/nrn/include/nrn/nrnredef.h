#ifndef nrnredef_h
#define nrnredef_h

#define net_send nrn_net_send
#define net_move nrn_net_move
#define net_event nrn_net_event

#endif
